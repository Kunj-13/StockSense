from dotenv import load_dotenv
import os
import openai
import chatgpt_ai.openai
from flask import Flask, request, jsonify
from chatgpt_ai.openai import chatgpt_response
from qdrant_client import QdrantClient
from utils import get_embeddings, search_for_context, form_prompt
from flask_cors import CORS

# Initialize Flask app
app = Flask(__name__)

CORS(app)

# Load environment variables from a .env file
load_dotenv()

# Set OpenAI API key from environment variables
api_key = chatgpt_ai.openai.api_key

# Initialize the Qdrant client
qdrant_client = QdrantClient()
collection_name = "Fed_Speeches"

@app.route('/process', methods=['POST'])
def process_message():
    #Get the incoming message from the POST request
    data = request.json  #Expecting a JSON body
    message_content = data.get('message')  #Extract the message from the JSON
    print("idk man",message_content,"hello there")

    #Ensure the message content is provided
    if not message_content:
        return jsonify({"error": "No message content provided"}), 400

    user_message = message_content
    #Proceed only if a valid command was detected
    clean_question = user_message.strip()
    print("before embeddings")
    search_vector = get_embeddings(clean_question)
    print("after embeddings")
    try:
        contexts = search_for_context(qdrant_client, collection_name, search_vector)
    except Exception as e:
        print("FAILED!!!!!!!!!!!!!!")
        return jsonify({"error": f"Qdrant connection failed: {e}"}), 500
    print("after searching")
    prompt = form_prompt(contexts, clean_question)
    print("we got a prompt boys")

    client2 = chatgpt_ai.openai.client

    bot_response = chatgpt_response(prompt,client2)

    return jsonify({"response": bot_response})
