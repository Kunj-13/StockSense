from dotenv import load_dotenv
import os
import openai
from flask import Flask, request, jsonify
from chatgpt_ai.openai import chatgpt_response
from qdrant_client import QdrantClient
from utils import get_embeddings, search_for_context, form_prompt

# Initialize Flask app
app = Flask(__name__)

# Load environment variables from a .env file
load_dotenv()

# Set OpenAI API key from environment variables
openai.api_key = os.getenv('OPENAI_API_KEY')

# Initialize the Qdrant client
qdrant_client = QdrantClient()
collection_name = 'Fed_Speeches'

@app.route('/process', methods=['POST'])
def process_message():
    # Get the incoming message from the POST request
    data = request.json  # Expecting a JSON body
    print(data)
    message_content = data.get('message')  # Extract the message from the JSON
    print(message_content,"hello there")

    # Ensure the message content is provided
    if not message_content:
        return jsonify({"error": "No message content provided"}), 400

    user_message = message_content
    # Proceed only if a valid command was detected
    clean_question = user_message.strip()
    search_vector = get_embeddings(clean_question)
    contexts = search_for_context(qdrant_client, collection_name, search_vector)
    prompt = form_prompt(contexts, clean_question)

    bot_response = chatgpt_response(prompt)

    if len(bot_response) > 2000:
        chunks = [bot_response[i:i + 2000] for i in range(0, len(bot_response), 2000)]
        return jsonify({"response_chunks": chunks})
    else:
        return jsonify({"response": bot_response})
