from flaskapi.flask_api import app
import subprocess

# Function to check if Node.js is installed
def checkNodeM():
    try:
        # Check if 'node' command works (assuming Node.js is installed)
        subprocess.run(['node', '--version'], check=True)
        print("Node.js is installed.")
    except FileNotFoundError:
        print("Node.js is not installed. Please install Node.js.")
        exit(1)


# Function to start the React app
def startReact():
    try:
        # Start the React app (assumes it's inside 'my-app')
        subprocess.Popen(['npm', 'start'], cwd='my-app', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print("React app started.")
    except FileNotFoundError:
        print("Error starting React. Please ensure 'npm' is available in the system PATH.")


if __name__ == '__main__':

    # Check if Node.js is installed
    checkNodeM()

    # Start React app in the background
    startReact()

    # Run the Flask server
    app.run(port=5000)
