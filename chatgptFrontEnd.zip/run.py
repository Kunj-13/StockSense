from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/process', methods=['POST'])
def process_data():
    data = request.json  # Get input data from the React app
    response = {"message": f"Received: {data['input']}"}
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True, port=5000)  # Run on port 5000 or any port you choose