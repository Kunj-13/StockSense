from dotenv import load_dotenv
import os
import openai
from flask import Flask, request, jsonify
from chatgpt_ai.openai import chatgpt_response
from qdrant_client import QdrantClient
from utils import get_embeddings, search_for_context, form_prompt

# Load environment variables from a .env file
load_dotenv()

# Set OpenAI API key from environment variables
openai.api_key = os.getenv('OPENAI_API_KEY')

# Initialize the Qdrant client
qdrant_client = QdrantClient()
collection_name = 'Fed_Speeches'

# Initialize Flask app
app = Flask(__name__)

@app.route('/process_message', methods=['POST'])
def process_message():
    # Get the incoming message from the POST request
    data = request.json  # Expecting a JSON body
    message_content = data.get('message')  # Extract the message from the JSON

    # Ensure the message content is provided
    if not message_content:
        return jsonify({"error": "No message content provided"}), 400

    # Detect the command and clean up the user message
    command, user_message = None, None
    for text in ['/ai', '/bot', '/financechatbot']:
        if message_content.startswith(text):
            command = text
            user_message = message_content.replace(text, '').strip()
            print(f'Command: {command}, User message: {user_message}')
            break

    # Proceed only if a valid command was detected
    if command:
        clean_question = user_message.strip()
        search_vector = get_embeddings(clean_question)
        contexts = search_for_context(qdrant_client, collection_name, search_vector)
        prompt = form_prompt(contexts, clean_question)

        # Get response from the chat model
        bot_response = chatgpt_response(prompt)

        # Split the response if it exceeds the character limit (Discord limit logic)
        if len(bot_response) > 2000:
            chunks = [bot_response[i:i + 2000] for i in range(0, len(bot_response), 2000)]
            return jsonify({"response_chunks": chunks})
        else:
            return jsonify({"response": bot_response})

    return jsonify({"error": "No valid command found"}), 400
