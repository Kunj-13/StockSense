import React, { useState } from 'react';

import './App.css';

const styles = {
  app: {
    display: 'flex',
    height: '100vh',
    fontFamily: 'Arial',
  },
  sidebar: {
    width: '200px',
    backgroundColor: '#000000',
    padding: '20px',
    color: 'white',
  },
  sidebarOption: {
    fontSize: '18px',
    padding: '10px 0',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },
  sidebarOptionHover: {
    backgroundColor: '#333333',
  },
  content: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
  },
  topSearchBar: {
    padding: '20px',
    borderBottom: '1px solid #ccc',
  },
  searchInput: {
    width: '100%',
    padding: '10px',
    fontSize: '16px',
  },
  chatArea: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    padding: '20px',
  },
  output: {
    flex: 1,
    border: '1px solid #ccc',
    borderRadius: '4px',
    padding: '20px',
    marginBottom: '20px',
    overflowY: 'auto',
  },
  bottomChatBar: {
    display: 'flex',
  },
  chatInput: {
    flex: 1,
    padding: '10px',
    fontSize: '16px',
  },
  button: {
    padding: '10px 20px',
    fontSize: '16px',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    cursor: 'pointer',
  },
  pre: {
    whiteSpace: 'pre-wrap',
    wordWrap: 'break-word',
  },
};

function Sidebar({ setCurrentPage }) {
  const [hoveredOption, setHoveredOption] = useState(null);

  const options = ['Chat 1', 'Chat 2', 'Chat 3', 'Graph'];

  return (
    <div className="sidebar">
      <h2 style={{ marginBottom: '30px' }}>StockSense</h2>
      <nav>
        {options.map((option, index) => (
          <div className="sidebarOption"
            key={index}
            style={{
              ...(hoveredOption === index ? styles.sidebarOptionHover : {})
            }}
            onMouseEnter={() => setHoveredOption(index)}
            onMouseLeave={() => setHoveredOption(null)}
            onClick={() => setCurrentPage(option.toLowerCase().replace(' ', ''))}
          >
            {option}
          </div>
        ))}
      </nav>
    </div>
  );
}

function ChatInterface({ chatId, chatHistory, setChatHistory }) {
  const [input, setInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
	if (input.trim()){
    const aiResponse = {
      type: 'ai_response',
      content: `You said: ${input.trim()}`,
      timestamp: new Date().toISOString(),
    };
    setChatHistory(prev => ({
      ...prev,
      [chatId]: [...(prev[chatId] || []), aiResponse],
    }));
	};
   setInput('');
  };

  return (
    <div className="content">
      <div className="topSearchBar">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search (functionless for now)..."
          style={styles.searchInput}
        />
      </div>
      <div className="chatArea">
        <div className="output">
          {chatHistory[chatId]?.map((msg, index) => (
            <pre key={index} style={styles.pre}>
              {JSON.stringify(msg, null, 2)}
            </pre>
          ))}
        </div>
        <form onSubmit={handleSubmit} className="bottomChatBar">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Chat with AI..."
            style={styles.chatInput}
          />
          <button type="submit" className="chatButton">Send</button>
        </form>
      </div>
    </div>
  );
}

function App() {
  const [chatHistory, setChatHistory] = useState({});
  const [currentPage, setCurrentPage] = useState('home');

  return (
    <div className="app">
      <Sidebar setCurrentPage={setCurrentPage} />
      <ChatInterface 
        chatId={currentPage} 
        chatHistory={chatHistory} 
        setChatHistory={setChatHistory}
      />
    </div>
  );
}

export default App;